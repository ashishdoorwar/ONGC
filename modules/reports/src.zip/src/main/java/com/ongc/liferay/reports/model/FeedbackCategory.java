package com.ongc.liferay.reports.model;

import java.util.Date;

public class FeedbackCategory {

	private int categoryId;
	private int feedbackId;
	private String description;
	private String createdBy;
	private Date createdOn;
	private String startDate;
	private String endDate;
	private String postId;
	private String keyword;
	
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public int getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getPostId() {
		return postId;
	}
	public void setPostId(String postId) {
		this.postId = postId;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	@Override
	public String toString() {
		return "FeedbackCategory [categoryId=" + categoryId + ", feedbackId=" + feedbackId + ", description="
				+ description + ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", postId=" + postId + ", keyword=" + keyword + "]";
	}

	
	
}
