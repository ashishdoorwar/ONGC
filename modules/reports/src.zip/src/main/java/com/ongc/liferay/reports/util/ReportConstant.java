package com.ongc.liferay.reports.util;

public class ReportConstant {

	public static final String ONGC_REPORT_EMPLOYEE	= "ongc.report.employee";
	public static final String ONGC_REPORT_EMPLOYEE1	= "ongc.report.employee1";
	public static final String ONGC_REPORT_ISD_SESSION_NAME = "ISDList";
	public static final String FEEDBACKPOST_LIST_ATTR_NAME="report.feedbackPostList";

	public static final int ORDER_CIRCULAR_ROW = 3;
	public static final String FILE_PATH = "/order&circular";
	public static final String REPORT_ADMIN = "reportAdmin"; 
	public static final int PROFILE_PIC_SIZE = 51200;
	public static final String COMMENT_STATUS_INACTIVE = "Inactive";
	public static final String COMMENT_STATUS_ACTIVE = "Active";
	
	//public static final String AD_ID="10.205.48.230";
	public static final String AD_ID="10.205.30.240";
	//public static final String AD_ID="10.205.30.240";
	
	public static final String AD_USER_ID = "reportswebuser";
	public static final String AD_USER_PASS = "R$ports@101";
	
	public static final String SMTP_HOST="10.205.48.55";
	
	public static final String SMS_USER = "ongc";
	public static final String SMS_PASS="ongc12";
	public static final String SMS_HOST="10.205.48.187";
	public static final String SMSC_PORT="13013";
	
	public static final String AUTHUSER[] = {"121229","57392","58987","90245","94592","95903","77242","94314","121841"};
	
	public static final String POST_STATUS_CLOSE = "CLOSE";
	public static final String POST_STATUS_OPEN = "OPEN";
	public static final String POST_STATUS_LOCAL = "LOCAL";
	public static final String POST_STATUS_CORPORATE = "CORPORATE";
	
	public static final String HRD_CORPORATE_ENABLER = "127088"; //Previously 81098
	public static final String OTHER_CORPORATE_ENABLER = "82277";
}

