package com.ongc.liferay.reports.service;

import com.ongc.liferay.reports.model.User;

import java.util.List;

public interface FindOngcianService {
	
	public List<User> getOngcian(User user);

}
