package com.ongc.liferay.sponsorship.model;
/**
 * @author Ranjeet
 */
public class SponStatus {

	private int statid;
	private String status;
	public int getStatid() {
		return statid;
	}
	public void setStatid(int statid) {
		this.statid = statid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}


	
}
