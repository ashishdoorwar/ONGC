package com.ongc.liferay.sponsorship.model;
/**
 * @author Ranjeet
 */
public class CreatedByBean {

}
