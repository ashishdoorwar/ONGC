package com.ongc.liferay.sponsorship.constants;

/**
 * @author Ranjeet
 */
public class SponsorshipPortletKeys {

	public static final String SPONSORSHIP =
		"com_liferay_ongc_sponsorship_SponsorshipPortlet";

}