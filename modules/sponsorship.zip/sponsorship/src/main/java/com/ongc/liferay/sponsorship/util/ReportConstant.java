package com.ongc.liferay.sponsorship.util;

public class ReportConstant {

	public static final int ORDER_CIRCULAR_ROW = 3;
	public static final String FILE_PATH = "/order&circular";
	public static final String REPORT_ADMIN = "reportAdmin";
	public static final String USERDTL = "user";

	public static final String SMTP_HOST = "10.205.48.55";

	public static final String SMS_USER = "ongc";
	public static final String SMS_PASS = "ongc12";
	public static final String SMS_HOST = "10.205.48.187";
	public static final String SMSC_PORT = "13013";

}
